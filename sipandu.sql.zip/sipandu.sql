-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 12, 2011 at 11:01 AM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sipandu`
--

-- --------------------------------------------------------

--
-- Table structure for table `bayi`
--

CREATE TABLE IF NOT EXISTS `bayi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jenis_kelamin` set('L','P') DEFAULT NULL,
  `berat` float DEFAULT NULL,
  `panjang` float DEFAULT NULL,
  `telp` varchar(255) DEFAULT NULL,
  `nama_ayah` varchar(255) DEFAULT NULL,
  `pekerjaan_ayah` varchar(255) DEFAULT NULL,
  `nama_ibu` varchar(255) DEFAULT NULL,
  `pekerjaan_ibu` varchar(255) DEFAULT NULL,
  `jalan` varchar(255) DEFAULT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `desa` varchar(255) DEFAULT NULL,
  `kecamatan` varchar(255) DEFAULT NULL,
  `kota` varchar(255) DEFAULT NULL,
  `propinsi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bayi`
--

INSERT INTO `bayi` (`id`, `nama`, `tgl_lahir`, `jenis_kelamin`, `berat`, `panjang`, `telp`, `nama_ayah`, `pekerjaan_ayah`, `nama_ibu`, `pekerjaan_ibu`, `jalan`, `rt`, `rw`, `desa`, `kecamatan`, `kota`, `propinsi`) VALUES
(1, 'Arief Hidayatulloh', '2010-01-25', 'L', 3, 30, '02518648219', 'Abdul Mutholib', 'Pegawai BUMD', 'Dedeh Karyanti', 'Wiraswasta', 'Moh. Noh. Noer', '05', '03', 'Barengkok', 'Leuwiliang', 'Bogor', 'Jawa Barat'),
(2, 'Alfa Nugraha', '2010-01-25', 'L', 4, 40, '', 'Ibnu Aga', 'Tukang Nyuci', 'Ibnu Siti', 'Pegawai Negeri Sipil', 'Moh. Noh. Noer', '05', '03', 'Barengkok', 'Leuwiliang', 'Bogor', 'Jawa Barat'),
(3, 'Nabil', '0000-00-00', 'P', 0, 0, '', '', '', '', '', '', '', '', '', '', '', ''),
(4, 'Ardi', '0000-00-00', 'L', 0, 0, '', '', '', '', '', '', '', '', '', '', '', ''),
(5, 'Icha', '2009-11-28', 'P', 3, 49, '025183225565', 'Bani', 'Pengusaha', 'Wina', 'Ibu rumah tangga', 'Babakan Lebak N0.7', '03', '07', 'Ciomas Rahayu', 'Ciomas', 'Bogor', 'Jawa Barat');

-- --------------------------------------------------------

--
-- Table structure for table `bayi_berita`
--

CREATE TABLE IF NOT EXISTS `bayi_berita` (
  `id_bayi` int(11) NOT NULL,
  `id_berita` int(11) NOT NULL,
  KEY `id_bayi` (`id_bayi`,`id_berita`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bayi_berita`
--

INSERT INTO `bayi_berita` (`id_bayi`, `id_berita`) VALUES
(1, 1),
(2, 1),
(2, 1),
(2, 2),
(3, 1),
(4, 1),
(4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
  `id_berita` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `waktu` varchar(20) DEFAULT NULL,
  `pelayanan` varchar(255) DEFAULT NULL,
  `fasilitas` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_berita`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id_berita`, `tanggal`, `waktu`, `pelayanan`, `fasilitas`, `keterangan`) VALUES
(1, '2011-04-11', '08.00 - 16.00', 'Imunisasi, Vitamin, Pengukuran Berat & Tinggi, Riwayat Kesehatan Anak', 'Meja, Kursi, Timbangan', 'Penurunan kualitas berat'),
(2, '2011-04-06', '08.00 - selesai', 'pemberian vitamin', 'meja', ';alnsdf;landsf;ln;sdn');

-- --------------------------------------------------------

--
-- Table structure for table `imunisasi`
--

CREATE TABLE IF NOT EXISTS `imunisasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `id_bayi` int(11) NOT NULL,
  `id_imunisasi` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_bayi` (`id_bayi`,`id_imunisasi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `imunisasi`
--

INSERT INTO `imunisasi` (`id`, `tanggal`, `id_bayi`, `id_imunisasi`) VALUES
(1, '2011-03-09', 3, 5),
(2, '2100-03-09', 3, 3),
(3, '2011-04-09', 3, 1),
(4, '2011-04-06', 3, 6);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_imunisasi`
--

CREATE TABLE IF NOT EXISTS `jenis_imunisasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `Kegunaan` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `jenis_imunisasi`
--

INSERT INTO `jenis_imunisasi` (`id`, `nama`, `Kegunaan`) VALUES
(1, 'BCG', 'mencegah TBC'),
(2, 'Hepatitis B', 'mencegah hepatitis'),
(3, 'DPT', 'mencegah dipteria, pertusis, dan tetanus'),
(4, 'Polio', 'mencegah polio'),
(5, 'campak', 'mencagah campak'),
(6, 'sehat', 'biar sehat');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_vitamin`
--

CREATE TABLE IF NOT EXISTS `jenis_vitamin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `ditemukan_pada` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `jenis_vitamin`
--

INSERT INTO `jenis_vitamin` (`id`, `nama`, `ditemukan_pada`) VALUES
(1, 'Vitamin A', 'Wortel'),
(2, 'Vitamin B', 'Susu, gandum, ikan, dan sayur-sayuran hijau'),
(3, 'Vitamin B1', 'Susu'),
(10, 'Vitamin B3', 'Gandum dan kentang manis'),
(9, 'Vitamin B2', 'Telur'),
(11, 'Vitamin B5', 'Susu'),
(12, 'Vitamin B6', 'Kacang'),
(13, 'Vitamin B12', 'Telur, hati, daging'),
(14, 'Vitamin C', 'Jeruk Sitrun'),
(15, 'Vitamin D', 'Keju'),
(16, 'Vitamin E', 'Minyak mata bulir gandum'),
(17, 'Vitamin K', 'Kuning telur');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan`
--

CREATE TABLE IF NOT EXISTS `pemeriksaan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `id_bayi` int(11) NOT NULL,
  `berat` float NOT NULL,
  `panjang` float DEFAULT NULL,
  `umur` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_bayi` (`id_bayi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `pemeriksaan`
--

INSERT INTO `pemeriksaan` (`id`, `tanggal`, `id_bayi`, `berat`, `panjang`, `umur`) VALUES
(1, '2011-03-14', 3, 3, 9, 0),
(2, '2011-03-08', 3, 3.4, 3, 1),
(3, '2011-03-13', 4, 0, 0, 0),
(4, '2011-03-07', 4, 0, 0, 1),
(5, '2011-03-15', 3, 4, 50, 2),
(6, '2011-03-10', 3, 6, 76, 5),
(7, '2011-03-07', 3, 3.7, 60, 3),
(8, '2011-03-08', 3, 5, 45, 4),
(9, '2011-05-05', 5, 5, 70, 5),
(10, '2011-06-06', 5, 6.6, 79, 6);

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE IF NOT EXISTS `petugas` (
  `id_petugas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_petugas` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id_petugas`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama_petugas`, `alamat`, `username`, `password`) VALUES
(1, 'Arif Hidayatulloh', 'babakan tengah', 'arif', 'arif'),
(2, 'Alfa Nugraha', 'babakan raya', 'alfa', 'alfa');

-- --------------------------------------------------------

--
-- Table structure for table `petugas_berita`
--

CREATE TABLE IF NOT EXISTS `petugas_berita` (
  `id_petugas` int(11) NOT NULL,
  `id_berita` int(11) NOT NULL,
  KEY `id_petugas` (`id_petugas`,`id_berita`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petugas_berita`
--

INSERT INTO `petugas_berita` (`id_petugas`, `id_berita`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vitamin`
--

CREATE TABLE IF NOT EXISTS `vitamin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `id_bayi` int(11) NOT NULL,
  `id_vitamin` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_bayi` (`id_bayi`,`id_vitamin`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `vitamin`
--

INSERT INTO `vitamin` (`id`, `tanggal`, `id_bayi`, `id_vitamin`) VALUES
(1, '2008-01-12', 3, 1),
(2, '2011-03-27', 3, 2),
(5, '2011-04-01', 3, 1);
